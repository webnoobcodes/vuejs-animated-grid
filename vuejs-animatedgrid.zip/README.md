# vuejs-animatedgrid

- [Tutorial on Youtube](https://youtu.be/GGBojjSr_1A)

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Run your tests
```
npm run test
```

### Lints and fixes files
```
npm run lint
```

## License

[MIT](LICENSE)
